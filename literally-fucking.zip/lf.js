/*
 *
 *  literally-fucking
 *  Declan Tyson
 *  v0.0.1
 *  09/10/2017
 *
 */

var html = document.querySelector('html');
html.innerHTML = html.innerHTML.replace(/literally/gi, '<strong>FUCKING</strong>');