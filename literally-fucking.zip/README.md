# Literally -> Fucking

### Why?

The word literally is often used incorrectly or unnecessarily. So let's replace it with a word to add more literally emphasis.